(() => {
  const root = document.getElementById("run-status");
  if (!root) return;
  const label = document.getElementById("run-phase");
  const tag = root.querySelector(".status-tag");
  const button = document.querySelector(".run-form button");
  const text = button?.querySelector("span:last-child");
  let wasRunning = root.dataset.running === "true";
  async function refresh() {
    try {
      const response = await fetch("/api/status", { headers: { Accept: "application/json" } });
      const status = await response.json();
      if (wasRunning && !status.running) {
        window.location.reload();
        return;
      }
      wasRunning = status.running;
      root.dataset.running = status.running ? "true" : "false";
      root.dataset.paused = status.paused ? "true" : "false";
      root.classList.toggle("is-running", status.running);
      root.classList.toggle("is-paused", status.paused);
      if (label) label.textContent = status.phase;
      if (tag) tag.innerHTML = status.stop_requested ? "جاري الإيقاف" : status.running ? '<i class="pulse"></i> قيد التنفيذ' : status.paused ? "متوقف" : "المجدول اليومي";
      if (button) button.disabled = status.running;
      if (text) text.textContent = status.running ? "جاري التشغيل" : status.paused ? "استئناف العمل" : "تشغيل الآن";
    } catch (_) {
      // The page remains usable if the local status endpoint is temporarily unavailable.
    }
  }
  window.setInterval(refresh, 5000);
})();
